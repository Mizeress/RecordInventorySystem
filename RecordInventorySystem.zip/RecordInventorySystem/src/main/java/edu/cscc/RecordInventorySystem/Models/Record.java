package edu.cscc.RecordInventorySystem.Models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

/**
 * @author Samuel Mallia
 * @version 04/24/2024
 */


@Entity
public class Record {
	//The validation in this model is not used by thymeleaf, but provides an
	//Additional layer of protection when data is persisted to the database
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	
	@NotEmpty()
	@Size(max=50, message="Title must be 50 characters or fewer.")
	private String title;
	
	@NotEmpty()
	@Size(max=40, message="Artist must be 40 characters of fewer.")
	private String artist;
	
	@NotEmpty()
	@Size(max=40, message="Label must be 40 characters of fewer.")
	private String label;
	
	@Min(value=1930, message="Please provide a date of 1930 or later.")
	private int releaseYear;
	
	@Min(value=1, message="A record must have at least one track.")
	@Max(value=20, message="Record too long. Please limit the number of tracks to 20 or fewer.")
	private int numTracks;
	
	private int size; 
	private boolean damaged;
	
	public Record() {
		
	}
	
	public Record(RecordRequest request) {
		this.title = request.getTitle();
		this.artist = request.getArtist();
		this.label = request.getLabel();
		this.releaseYear = request.getReleaseYear();
		this.numTracks = request.getNumTracks();
		this.size = request.getSize();
		this.damaged = request.isDamaged();
	}
	
	//Getters and Setters
	public long getId() {
		return id;
	}
	
	public void setId(long id) {
		this.id = id;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getArtist() {
		return artist;
	}
	public void setArtist(String artist) {
		this.artist = artist;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public int getReleaseYear() {
		return releaseYear;
	}
	public void setReleaseYear(int releaseYear) {
		this.releaseYear = releaseYear;
	}
	public int getNumTracks() {
		return numTracks;
	}
	public void setNumTracks(int numTracks) {
		this.numTracks = numTracks;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public boolean isDamaged() {
		return damaged;
	}
	public void setDamaged(boolean isDamaged) {
		this.damaged = isDamaged;
	}
	
	
	
}
