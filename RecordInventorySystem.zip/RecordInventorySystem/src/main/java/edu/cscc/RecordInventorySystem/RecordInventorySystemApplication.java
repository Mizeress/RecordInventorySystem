package edu.cscc.RecordInventorySystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecordInventorySystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecordInventorySystemApplication.class, args);
	}

}
