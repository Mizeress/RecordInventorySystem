package edu.cscc.RecordInventorySystem.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import edu.cscc.RecordInventorySystem.Models.Record;
import edu.cscc.RecordInventorySystem.Models.RecordRequest;
import edu.cscc.RecordInventorySystem.repository.RecordRepository;
import jakarta.validation.Valid;

/**
 * @author Samuel Mallia
 * @version 04/24/2024
 */

@Controller
public class RecordInventoryController {
	
	@Autowired
	RecordRepository repo;
	
	//End point for a form to add a record
	@GetMapping("/add-record")
	String addRecord(Model model) {
		model.addAttribute("request", new RecordRequest());
		
		//The number of records that will be in the system after completing form
		model.addAttribute("count", repo.count() + 1);
		return "addRecord";
	}
	
	//The post method called by the add record form.
	@PostMapping("/records")
	public String postRecord(@Valid @ModelAttribute("request") RecordRequest request, BindingResult bindingResult, Model model) {
		//If there are errors, reload the form
		if(bindingResult.hasErrors()) {
			model.addAttribute("count", repo.count() + 1);
			return "addRecord";
			
		} else {
			//Build record from request and save to the repository
			Record newRecord = new Record(request);
			newRecord = repo.save(newRecord);
		
			return "redirect:/records/" + newRecord.getId();
		}
	}
	
	//Endpoint to display all records
	@GetMapping("/records")
	String allRecords(Model model) {
		model.addAttribute("records", repo.findAll());
		return "allRecords";
	}
	
	//Endpoint for a single record's page
	@GetMapping("/records/{id}")
	String singleRecord(Model model, @PathVariable long id) {
		model.addAttribute("record", repo.findById(id).get());
		
		return "recordPage";
	}
	
	//My implementation for deleting a record. Used post mapping as I don't know a simple way to send a delete request in html but I knew how to do this.
	//I decided to implement this so I could more easily test the app without having to manually delete records all the time
	@PostMapping("/delete-record/{id}")
	String removeRecord(@PathVariable long id) {
		repo.delete(repo.findById(id).get());
		
		return "redirect:/records";
	}
}
