package edu.cscc.RecordInventorySystem.repository;

import org.springframework.data.repository.CrudRepository;
import edu.cscc.RecordInventorySystem.Models.Record;

public interface RecordRepository extends CrudRepository<Record, Long> {

}
